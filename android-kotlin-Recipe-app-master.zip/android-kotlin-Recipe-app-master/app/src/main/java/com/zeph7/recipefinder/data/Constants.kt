package com.zeph7.recipefinder.data

val LEFT_LINK: String = "http://www.recipepuppy.com/api/?i="
val QUERY: String = "&q="